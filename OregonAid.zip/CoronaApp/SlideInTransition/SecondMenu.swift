//
//  Created by Ali Fakhry on 5/11/20.
//


import UIKit
import Foundation

enum NextMenu: Int {
    case blog
    case contact
    case masks
    case tips
    case stats
}

class SecondMenu: UITableViewController {
    
    
    
    var didTapMenuType: ((NextMenu) -> Void)?

    override func viewDidLoad() {
                      

    super.viewDidLoad()
        
    // Do any additional setup after loading the view.
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let menuType = NextMenu(rawValue: indexPath.row) else { return }
        dismiss(animated: true) { [weak self] in
            print("Dismissing: \(menuType)")
            self?.didTapMenuType?(menuType)
        }
    }
    @available(iOS 13.0, *)
    @IBAction func NewsClicked(_ sender: Any) {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let secondVC = storyboard.instantiateViewController(identifier: "Extras")
            secondVC.modalPresentationStyle = .fullScreen
            secondVC.modalTransitionStyle = .crossDissolve
            present(secondVC, animated: true, completion: nil)
    }
    @available(iOS 13.0, *)
    @IBAction func ContactClicked(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                   let secondVC = storyboard.instantiateViewController(identifier: "FirstChildVC")
                   secondVC.modalPresentationStyle = .fullScreen
                   secondVC.modalTransitionStyle = .crossDissolve
                   present(secondVC, animated: true, completion: nil)
    }
    @available(iOS 13.0, *)
    @IBAction func MasksClicked(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                          let secondVC = storyboard.instantiateViewController(identifier: "MasksStuff")
                          secondVC.modalPresentationStyle = .fullScreen
                          secondVC.modalTransitionStyle = .crossDissolve
                          present(secondVC, animated: true, completion: nil)
    }
    @available(iOS 13.0, *)
    @IBAction func HealthClicked(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                 let secondVC = storyboard.instantiateViewController(identifier: "HomeViewControlled")
                                 secondVC.modalPresentationStyle = .fullScreen
                                 secondVC.modalTransitionStyle = .crossDissolve
                                 present(secondVC, animated: true, completion: nil)
    }
    @available(iOS 13.0, *)
    @IBAction func StatsClicked(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                        let secondVC = storyboard.instantiateViewController(identifier: "NewStats")
                                        secondVC.modalPresentationStyle = .fullScreen
                                        secondVC.modalTransitionStyle = .crossDissolve
                                        present(secondVC, animated: true, completion: nil)
    }
    @available(iOS 13.0, *)
    @IBAction func buttonHome(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let secondVC = storyboard.instantiateViewController(identifier: "Navigation")
        secondVC.modalPresentationStyle = .fullScreen
        secondVC.modalTransitionStyle = .crossDissolve
        present(secondVC, animated: true, completion: nil)
    }
    @available(iOS 13.0, *)
    @IBAction func MapClicked(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let secondVC = storyboard.instantiateViewController(identifier: "Location")
        secondVC.modalPresentationStyle = .fullScreen
        secondVC.modalTransitionStyle = .crossDissolve
        present(secondVC, animated: true, completion: nil)
    }
}



