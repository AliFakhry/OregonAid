//
//  Created by Ali Fakhry on 5/11/20.
//


import UIKit
import Foundation
import UIKit
import MessageUI

enum ExternalMenu: Int {
    case home
    case blog
    case contact
    case masks
    case tips
    case stats
}

class FirstChildVC: UITableViewController, MFMailComposeViewControllerDelegate {
    
    
    
    var didTapMenuType: ((ExternalMenu) -> Void)?

    override func viewDidLoad() {
                      
      
                       
                        
                       DispatchQueue.main.async
                       {

                       }
    
    super.viewDidLoad()
        
    // Do any additional setup after loading the view.
    }
    
    @IBAction func InstaClickedAgain(_ sender: Any) {
        let Username =  "OregonAid"
              let appURL = URL(string: "instagram://user?username=\(Username)")!
              let application = UIApplication.shared

              if application.canOpenURL(appURL) {
                  application.open(appURL)
              } else {
                  let webURL = URL(string: "https://instagram.com/\(Username)")!
                  application.open(webURL)
              }
    }
    
    @IBAction func MailClickedAgain(_ sender: Any) {
        // Modify following variables with your text / recipient
        let recipientEmail = "OregonAid@gmail.com"
        let subject = "OregonAid"
        let body = "Say Hello! :)"

        // Show default mail composer
        if MFMailComposeViewController.canSendMail() {
            let mail = MFMailComposeViewController()
            mail.mailComposeDelegate = self
            mail.setToRecipients([recipientEmail])
            mail.setSubject(subject)
            mail.setMessageBody(body, isHTML: false)

            present(mail, animated: true)

        // Show third party email composer if default Mail app is not present
        } else if let emailUrl = createEmailUrl(to: recipientEmail, subject: subject, body: body) {
            UIApplication.shared.open(emailUrl)
        }
    }
    @IBAction func TwitterPressed(_ sender: Any) {
          let screenName =  "AidOregon"
        let appURL = NSURL(string: "twitter://user?screen_name=\(screenName)")!
        let webURL = NSURL(string: "https://twitter.com/\(screenName)")!

        let application = UIApplication.shared

        if application.canOpenURL(appURL as URL) {
             application.open(appURL as URL)
        } else {
             application.open(webURL as URL)
        }
    }
    private func createEmailUrl(to: String, subject: String, body: String) -> URL? {
        let subjectEncoded = subject.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
        let bodyEncoded = body.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!

        let gmailUrl = URL(string: "googlegmail://co?to=\(to)&subject=\(subjectEncoded)&body=\(bodyEncoded)")
        let outlookUrl = URL(string: "ms-outlook://compose?to=\(to)&subject=\(subjectEncoded)")
        let yahooMail = URL(string: "ymail://mail/compose?to=\(to)&subject=\(subjectEncoded)&body=\(bodyEncoded)")
        let sparkUrl = URL(string: "readdle-spark://compose?recipient=\(to)&subject=\(subjectEncoded)&body=\(bodyEncoded)")
        let defaultUrl = URL(string: "mailto:\(to)?subject=\(subjectEncoded)&body=\(bodyEncoded)")

        if let gmailUrl = gmailUrl, UIApplication.shared.canOpenURL(gmailUrl) {
            return gmailUrl
        } else if let outlookUrl = outlookUrl, UIApplication.shared.canOpenURL(outlookUrl) {
            return outlookUrl
        } else if let yahooMail = yahooMail, UIApplication.shared.canOpenURL(yahooMail) {
            return yahooMail
        } else if let sparkUrl = sparkUrl, UIApplication.shared.canOpenURL(sparkUrl) {
            return sparkUrl
        }

        return defaultUrl
    }

    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true)
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let menuType = ExternalMenu(rawValue: indexPath.row) else { return }
        dismiss(animated: true) { [weak self] in
            print("Dismissing: \(menuType)")
            self?.didTapMenuType?(menuType)
        }
    }
}



