import MessageUI
import UIKit

class Volunteer: UIViewController, MFMailComposeViewControllerDelegate, UITextFieldDelegate {
    @IBOutlet weak var SendButton: UIButton!
    @IBOutlet weak var WhyButton: UIButton!
    @IBOutlet weak var FirstName: UITextField!
    @IBOutlet weak var LastName: UITextField!
    @IBOutlet weak var PhoneNumber: UITextField!
    @IBOutlet weak var Help: UITextField!
    @IBOutlet weak var Note: UITextField!
    
    @IBAction func SendButton(_ sender: Any) {
        
        var text:  String =  FirstName.text!
        var text2: String = LastName.text!
        var text3: String = String(PhoneNumber.text!)
        var text4: String = Help.text!
        var text5: String = Note.text!
        

        
        // Modify following variables with your text / recipient
            let recipientEmail = "OregonAid@gmail.com"
            let subject = "OregonAid Volunteer"
            let body = "Hello, my name is " + text + text2 + ". \n I can help with: " + text4 + ". \n I have to say, however, that: " + text4 + ". \n My phone number is: " + text3 + "."

            // Show default mail composer
            if MFMailComposeViewController.canSendMail() {
                let mail = MFMailComposeViewController()
                mail.mailComposeDelegate = self
                mail.setToRecipients([recipientEmail])
                mail.setSubject(subject)
                mail.setMessageBody(body, isHTML: false)

                present(mail, animated: true)

            // Show third party email composer if default Mail app is not present
            } else if let emailUrl = createEmailUrl(to: recipientEmail, subject: subject, body: body) {
                UIApplication.shared.open(emailUrl)
            }
        }
    
    private func createEmailUrl(to: String, subject: String, body: String) -> URL? {
        let subjectEncoded = subject.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
        let bodyEncoded = body.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!

        let gmailUrl = URL(string: "googlegmail://co?to=\(to)&subject=\(subjectEncoded)&body=\(bodyEncoded)")
        let outlookUrl = URL(string: "ms-outlook://compose?to=\(to)&subject=\(subjectEncoded)")
        let yahooMail = URL(string: "ymail://mail/compose?to=\(to)&subject=\(subjectEncoded)&body=\(bodyEncoded)")
        let sparkUrl = URL(string: "readdle-spark://compose?recipient=\(to)&subject=\(subjectEncoded)&body=\(bodyEncoded)")
        let defaultUrl = URL(string: "mailto:\(to)?subject=\(subjectEncoded)&body=\(bodyEncoded)")

        if let gmailUrl = gmailUrl, UIApplication.shared.canOpenURL(gmailUrl) {
            return gmailUrl
        } else if let outlookUrl = outlookUrl, UIApplication.shared.canOpenURL(outlookUrl) {
            return outlookUrl
        } else if let yahooMail = yahooMail, UIApplication.shared.canOpenURL(yahooMail) {
            return yahooMail
        } else if let sparkUrl = sparkUrl, UIApplication.shared.canOpenURL(sparkUrl) {
            return sparkUrl
        }

        return defaultUrl
    }

    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)

        let alertController = UIAlertController(title: "Hello!", message: "By volunteering, you can help bring materials, supplies, and resources to those in need! You can also help contact those who need help and discuss their needs. Thanks!", preferredStyle: .alert)

        alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
           super.viewDidLoad()
        
           // Do any additional setup after loading the view, typically from a nib.

           self.FirstName.delegate = self
           self.LastName.delegate = self
           self.PhoneNumber.delegate = self
           self.Help.delegate = self
           self.Note.delegate = self
        
           SendButton.layer.cornerRadius = 10.0
           SendButton.layer.masksToBounds = true
       }

       func textFieldShouldReturn(_ textField: UITextField) -> Bool {
           self.view.endEditing(true)
           return false
       }
}

