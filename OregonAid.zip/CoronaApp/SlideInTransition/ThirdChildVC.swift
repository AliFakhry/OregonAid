//
//  Created by Ali Fakhry on 5/11/20.
//


import UIKit
import Foundation

enum NewestNewMenu: Int {
    case home
    case blog
    case contact
    case masks
    case tips
    case stats
}

class ThirdChildVC: UITableViewController {
    
    
    
    var didTapMenuType: ((NewestNewMenu) -> Void)?

    override func viewDidLoad() {
                      
      
                       
                        
                       DispatchQueue.main.async
                       {

                       }
    
    super.viewDidLoad()
        
    // Do any additional setup after loading the view.
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let menuType = NewestNewMenu(rawValue: indexPath.row) else { return }
        dismiss(animated: true) { [weak self] in
            print("Dismissing: \(menuType)")
            self?.didTapMenuType?(menuType)
        }
    }
}



