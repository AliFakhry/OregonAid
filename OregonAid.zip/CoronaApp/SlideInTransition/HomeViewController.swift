//
//  Created by Ali Fakhry on 5/1/19.
//  Copyright © 2020s. All rights reserved.
//

import UIKit

@available(iOS 13.0, *)
class HomeViewController: UIViewController {
    @IBOutlet weak var GifView: UIImageView!
    @IBOutlet weak var ANIMATION: UIButton!
    @IBOutlet weak var MI: UIButton!
    
    let transiton = SlideInTransition()
    var topView: UIView?

    override func viewDidLoad() {
        
        ANIMATION.layer.cornerRadius = 20.0
        ANIMATION.layer.masksToBounds = true
        
        MI.layer.cornerRadius = 20.0
        MI.layer.masksToBounds = true
        
        super.viewDidLoad()
        GifView.loadGif(name: "MASKGIF")
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    
    @IBAction func didTapMenu(_ sender: UIBarButtonItem) {
        guard let menuViewController = storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as? MenuViewController else { return }
        menuViewController.didTapMenuType = { menuType in
            self.transitionToNew(menuType)
        }
        menuViewController.modalPresentationStyle = .overCurrentContext
        menuViewController.transitioningDelegate = self
        present(menuViewController, animated: true)
    }

    func transitionToNew(_ menuType: MenuType) {
        let title = String(describing: menuType).capitalized
        self.title = title

        topView?.removeFromSuperview()
        switch menuType {
        case .tips:
               let storyboard = UIStoryboard(name: "Main", bundle: nil)
               let secondVC = storyboard.instantiateViewController(identifier: "HomeViewControlled")
               
               secondVC.modalPresentationStyle = .fullScreen
               secondVC.modalTransitionStyle = .crossDissolve

               present(secondVC, animated: true, completion: nil)
        case .map:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let secondVC = storyboard.instantiateViewController(identifier: "Location")
            
            secondVC.modalPresentationStyle = .fullScreen
            secondVC.modalTransitionStyle = .crossDissolve

            present(secondVC, animated: true, completion: nil)
        case .stats:
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let secondVC = storyboard.instantiateViewController(identifier: "NewStats")
                
                secondVC.modalPresentationStyle = .fullScreen
                secondVC.modalTransitionStyle = .crossDissolve

                present(secondVC, animated: true, completion: nil)
        case .extras:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let secondVC = storyboard.instantiateViewController(identifier: "Extras")
            
            secondVC.modalPresentationStyle = .fullScreen
            secondVC.modalTransitionStyle = .crossDissolve

            present(secondVC, animated: true, completion: nil)

        default:
            break
        }
    }
}

@available(iOS 13.0, *)
extension HomeViewController: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = true
        return transiton
    }

    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = false
        return transiton
    }
}
