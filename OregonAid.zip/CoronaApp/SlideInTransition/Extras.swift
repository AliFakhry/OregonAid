//
//  Extras.swift
//  OregonAid
//
//  Created by DoomDragon on 7/3/20.
//  Copyright © 2020 SunCov. All rights reserved.
//

import UIKit

class Extras: UIViewController {

    @IBOutlet weak var NewsButton: UIButton!
    @IBOutlet weak var ContactButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NewsButton.layer.cornerRadius = 20.0
        NewsButton.layer.masksToBounds = true
        
        ContactButton.layer.cornerRadius = 20.0
        ContactButton.layer.masksToBounds = true
        
        // Do any additional setup after loading the view.
    }
    @available(iOS 13.0, *)
    @IBAction func NewsPressed(_ sender: Any) {
    let storyboard = UIStoryboard(name: "Main", bundle: nil)
    let secondVC = storyboard.instantiateViewController(identifier: "Oregon")
                           secondVC.modalPresentationStyle = .fullScreen
                           secondVC.modalTransitionStyle = .crossDissolve
                           present(secondVC, animated: true, completion: nil)
    }
    @available(iOS 13.0, *)
    @IBAction func ContactPressed(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let secondVC = storyboard.instantiateViewController(identifier: "FirstChildVC")
       secondVC.modalPresentationStyle = .fullScreen
       secondVC.modalTransitionStyle = .crossDissolve
       present(secondVC, animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
