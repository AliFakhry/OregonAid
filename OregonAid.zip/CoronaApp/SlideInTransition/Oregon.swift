//
//  Created by Ali Fakhry on 5/11/20.
//


import UIKit
import Foundation

enum NewestMenu: Int {
    case home
    case blog
    case contact
    case masks
    case tips
    case stats
}

class Oregon: UITableViewController {
    
    
    
    var didTapMenuType: ((NewestMenu) -> Void)?

    override func viewDidLoad() {
                      
      
                       
                        
                       DispatchQueue.main.async
                       {

                       }
    
    super.viewDidLoad()
    }
    @IBAction func CasesClicked(_ sender: Any) {
        let appURL = URL(string: "https://www.oregonlive.com/search/?q=HomelessnessCases")!
        let application = UIApplication.shared

        if application.canOpenURL(appURL) {
            application.open(appURL)
        } else {
            let webURL = URL(string: "https://www.oregonlive.com/search/?q=HomelessnessCases")!
            application.open(webURL)
        }
    }
    @IBAction func PoliciesClicked(_ sender: Any) {
               let appURL = URL(string: "https://www.oregonlive.com/search/?q=HomelessnessPolicies")!
               let application = UIApplication.shared

               if application.canOpenURL(appURL) {
                   application.open(appURL)
               } else {
                   let webURL = URL(string: "https://www.oregonlive.com/search/?q=HomelessnessPolicies")!
                   application.open(webURL)
               }
    }
    @IBAction func OthersClicked(_ sender: Any) {
        let Username =  "Coronavirusoregon"
               let appURL = URL(string: "https://www.oregonlive.com/search/?q=Homeless")!
               let application = UIApplication.shared

               if application.canOpenURL(appURL) {
                   application.open(appURL)
               } else {
                   let webURL = URL(string: "https://www.oregonlive.com/search/?q=Homeless")!
                   application.open(webURL)
               }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let menuType = NewestMenu(rawValue: indexPath.row) else { return }
        dismiss(animated: true) { [weak self] in
            print("Dismissing: \(menuType)")
            self?.didTapMenuType?(menuType)
        }
    }
}



