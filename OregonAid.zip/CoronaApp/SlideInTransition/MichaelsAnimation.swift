//
//  MichaelsAnimation.swift
//  SlideInTransition
//
//  Created by DoomDragon on 5/27/20.
//  Copyright © 2020 Gary Tokman. All rights reserved.
//

import UIKit
import AVKit

class MichaelsAnimation: UIViewController {

    override func viewDidLoad() {
        let refreshAlert = UIAlertController(title: "Warning:", message: "This animation has been produced by our team and is protected under copyright laws.", preferredStyle: UIAlertController.Style.alert)

        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
              print("Handle Ok logic here")
        }))

        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
              print("Handle Cancel Logic here")
        }))

        present(refreshAlert, animated: true, completion: nil)
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


    @IBAction func buttonAction(_ sender: Any) {
        if let path = Bundle.main.path(forResource: "video", ofType: "mp4")
        {
            let video = AVPlayer(url: URL(fileURLWithPath: path))
            let videoPlayer = AVPlayerViewController()
            videoPlayer.player = video
            
            present(videoPlayer, animated: true, completion:
            {
                video.play()
            })
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
