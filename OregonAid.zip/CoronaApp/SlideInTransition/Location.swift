//
//  ViewController.swift
//  map-kit-tutorial-1
//
//  Created by Code Pro on 1/28/18.
//  Copyright © 2018 Code Pro. All rights reserved.
//

import UIKit
import MapKit

class Location: UIViewController {
    
    private let locationManager = CLLocationManager()
    private var currentCoordinate: CLLocationCoordinate2D?
    
    private var destinations: [MKPointAnnotation] = []
    private var currentRoute: MKRoute?

    @IBOutlet weak var mapView: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
        
        configureLocationServices()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    private func configureLocationServices() {
        locationManager.delegate = self
        let status = CLLocationManager.authorizationStatus()
        
        if status == .notDetermined {
            locationManager.requestAlwaysAuthorization()
        } else if status == .authorizedAlways || status == .authorizedWhenInUse {
           beginLocationUpdates(locationManager: locationManager)
        }
    }
    
    private func beginLocationUpdates(locationManager: CLLocationManager) {
        mapView.showsUserLocation = true
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.startUpdatingLocation()
    }
    
    private func zoomToLatestLocation(with coordinate: CLLocationCoordinate2D) {
        let zoomRegion = MKCoordinateRegion(center: coordinate, latitudinalMeters: 10000, longitudinalMeters: 10000)
        mapView.setRegion(zoomRegion, animated: true)
    }
    
    private func addAnnotations() {
        
        let appleParkAnnotation = MKPointAnnotation()
        appleParkAnnotation.title = "OHSU"
        appleParkAnnotation.coordinate = CLLocationCoordinate2D(latitude: 45.499103, longitude: -122.685763)
        let ortegaParkAnnotation = MKPointAnnotation()
        ortegaParkAnnotation.title = "Union Gospel Mission"
        ortegaParkAnnotation.coordinate = CLLocationCoordinate2D(latitude:  45.523306, longitude: -122.673601)
        let hospital = MKPointAnnotation()
        hospital.title = "Samaritan Albany General Hospital"
        hospital.coordinate = CLLocationCoordinate2D(latitude:  44.631585, longitude: -123.116590)
        let GoodCenter = MKPointAnnotation()
        GoodCenter.title = "Good Neighbor Center"
        GoodCenter.coordinate = CLLocationCoordinate2D(latitude:   45.439813, longitude: -122.779271)
        let PortlandRescue = MKPointAnnotation()
        PortlandRescue.title = "Portland Rescue Mission"
        PortlandRescue.coordinate = CLLocationCoordinate2D(latitude:   45.523295, longitude: -122.671571)
        let Family = MKPointAnnotation()
        Family.title = "Community Action Family Shelter"
        Family.coordinate = CLLocationCoordinate2D(latitude:   45.520905, longitude: -122.969714)
        let Joseph = MKPointAnnotation()
        Joseph.title = "St Joseph Shelter"
        Joseph.coordinate = CLLocationCoordinate2D(latitude:   45.061151, longitude:  -122.804150)
        let Father = MKPointAnnotation()
        Father.title = "Father's Heart Street Ministry"
        Father.coordinate = CLLocationCoordinate2D(latitude: 45.359907, longitude:  -122.600978)
        let Helping = MKPointAnnotation()
        Helping.title = "Helping Hands Reentry Outreach Centers"
        Helping.coordinate = CLLocationCoordinate2D(latitude: 45.289785, longitude:  -122.945860)
        let Access = MKPointAnnotation()
        Access.title = "Access and Assessment Center"
        Access.coordinate = CLLocationCoordinate2D(latitude: 45.522224, longitude:  -122.679826)
    
        
        destinations.append(appleParkAnnotation)
        destinations.append(ortegaParkAnnotation)
        destinations.append(hospital)
        destinations.append(GoodCenter)
        destinations.append(PortlandRescue)
        destinations.append(Family)
        destinations.append(Joseph)
        destinations.append(Father)
        destinations.append(Helping)
        destinations.append(Access)



        mapView.addAnnotation(hospital)
        mapView.addAnnotation(appleParkAnnotation)
        mapView.addAnnotation(ortegaParkAnnotation)
        mapView.addAnnotation(GoodCenter)
        mapView.addAnnotation(PortlandRescue)
        mapView.addAnnotation(Family)
        mapView.addAnnotation(Joseph)
        mapView.addAnnotation(Father)
        mapView.addAnnotation(Helping)
        mapView.addAnnotation(Access)




        

    }
    
    private func constructRoute(userLocation: CLLocationCoordinate2D) {
        
        let directionsRequest = MKDirections.Request()
        directionsRequest.source = MKMapItem(placemark: MKPlacemark(coordinate: userLocation))
        directionsRequest.destination = MKMapItem(placemark: MKPlacemark(coordinate: destinations[0].coordinate))
        directionsRequest.requestsAlternateRoutes = true
        directionsRequest.transportType = .automobile
        
        let directions = MKDirections(request: directionsRequest)
        
        directions.calculate { [weak self] (directionsResponse, error) in
            
            guard let strongSelf = self else { return }
            
            if let error = error {
                print(error.localizedDescription)
            } else if let response = directionsResponse, response.routes.count > 0 {
                
                strongSelf.currentRoute = response.routes[0]
                strongSelf.mapView.addOverlay(response.routes[0].polyline)
                strongSelf.mapView.setVisibleMapRect(response.routes[0].polyline.boundingMapRect, animated: true)
            }
        }
    }
}

extension Location: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("Did get latest location")
        
        guard let latestLocation = locations.first else { return }
        
        if currentCoordinate == nil {
            zoomToLatestLocation(with: latestLocation.coordinate)
            addAnnotations()
            constructRoute(userLocation: latestLocation.coordinate)
        }
    
        currentCoordinate = latestLocation.coordinate
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
       print("The status changed")
        if status == .authorizedAlways || status == .authorizedWhenInUse {
            beginLocationUpdates(locationManager: manager)
        }
    }
}

extension Location: MKMapViewDelegate {
    
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "AnnotationView")
        
        if annotationView == nil {
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "AnnotationView")
        }
        
        if let title = annotation.title, title == "OHSU" {
            annotationView?.image = UIImage(named: "pin2")
        } else if let title = annotation.title, title == "Union Gospel Mission" {
            annotationView?.image = UIImage(named: "pin3")
        }
        else if let title = annotation.title, title == "Samaritan Albany General Hospital" {
            annotationView?.image = UIImage(named: "pin2")
        }
        else if let title = annotation.title, title == "Good Neighbor Center" {
            annotationView?.image = UIImage(named: "pin3")
        }
        else if let title = annotation.title, title == "Portland Rescue Mission" {
                annotationView?.image = UIImage(named: "pin3")
        }
        else if let title = annotation.title, title == "Community Action Family Shelter" {
                          annotationView?.image = UIImage(named: "pin3")
        }
        else if let title = annotation.title, title == "St Joseph Shelter" {
                        annotationView?.image = UIImage(named: "pin3")
        }
        else if let title = annotation.title, title == "Father's Heart Street Ministry" {
                        annotationView?.image = UIImage(named: "pin3")
        }
        else if let title = annotation.title, title == "Helping Hands Reentry Outreach Centers" {
                        annotationView?.image = UIImage(named: "pin3")
        }
        else if let title = annotation.title, title == "Access and Assessment Center" {
                               annotationView?.image = UIImage(named: "pin3")
        }
        else if annotation === mapView.userLocation {
            annotationView?.image = UIImage(named: "pin")
        }
        
        annotationView?.canShowCallout = true
        
        return annotationView
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        print("The annotation was selected: \(String(describing: view.annotation?.title))")
    }
}


