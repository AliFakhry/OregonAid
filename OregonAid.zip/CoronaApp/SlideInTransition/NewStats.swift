

import UIKit
import Foundation

enum NewMenu: Int {
    case home
    case blog
    case contact
    case masks
    case tips
    case stats
}

class NewStats: UITableViewController {
    
    
    
    var didTapMenuType: ((NewMenu) -> Void)?
    @IBOutlet weak var TotalText: UILabel!
    @IBOutlet weak var TotalProgress: UIProgressView!
    @IBOutlet weak var MultnomahText: UILabel!
    @IBOutlet weak var MultnomahView: UIProgressView!
    @IBOutlet weak var MarionText: UILabel!
    @IBOutlet weak var MarionProgress: UIProgressView!
    @IBOutlet weak var WashingtonText: UILabel!
    @IBOutlet weak var WashingtonProgress: UIProgressView!
    @IBOutlet weak var ClackmasText: UILabel!
    @IBOutlet weak var ClackmasProgress: UIProgressView!
    @IBOutlet weak var LinnText: UILabel!
    @IBOutlet weak var LinnProgress: UIProgressView!
    @IBOutlet weak var DeschutesText: UILabel!
    @IBOutlet weak var DeschutesProgress: UIProgressView!
    @IBOutlet weak var UmatillaText: UILabel!
    @IBOutlet weak var KlamathProgress: UIProgressView!
    @IBOutlet weak var UmatillaProgress: UIProgressView!
    @IBOutlet weak var PolkText: UILabel!
    @IBOutlet weak var PolkProgress: UIProgressView!
    @IBOutlet weak var LaneText: UILabel!
    @IBOutlet weak var LaneProgress: UIProgressView!
    @IBOutlet weak var YamhillText: UILabel!
    @IBOutlet weak var YamhillProgress: UIProgressView!
    @IBOutlet weak var BentonText: UILabel!
    @IBOutlet weak var BentonProgress: UIProgressView!
    @IBOutlet weak var Klamath: UILabel!
    @IBOutlet weak var JacksonText: UILabel!
    @IBOutlet weak var JacksonProgress: UIProgressView!
    @IBOutlet weak var LincolnText: UILabel!
    @IBOutlet weak var LincolnProgress: UIProgressView!
    @IBOutlet weak var ClatsopText: UILabel!
    @IBOutlet weak var ClatsopProgress: UIProgressView!
    @IBOutlet weak var CoosText: UILabel!
    @IBOutlet weak var CoosProgress: UIProgressView!
    @IBOutlet weak var JosephineText: UILabel!
    @IBOutlet weak var JosephineProgress: UIProgressView!
    @IBOutlet weak var DouglasText: UILabel!
    @IBOutlet weak var DouglasProgress: UIProgressView!
    @IBOutlet weak var JeffersonText: UILabel!
    @IBOutlet weak var JeffersonProgress: UIProgressView!
    @IBOutlet weak var MalheurText: UILabel!
    @IBOutlet weak var MalheurProgress: UIProgressView!
    @IBOutlet weak var ColumbiaText: UILabel!
    @IBOutlet weak var ColumbiaProgress: UIProgressView!
    @IBOutlet weak var WascoText: UILabel!
    @IBOutlet weak var WascoProgress: UIProgressView!
    @IBOutlet weak var HoodRiverText: UILabel!
    @IBOutlet weak var HoodRiverProgress: UIProgressView!
    @IBOutlet weak var MorrowText: UILabel!
    @IBOutlet weak var MorrowProgress: UIProgressView!
    @IBOutlet weak var TilamookText: UILabel!
    @IBOutlet weak var TilamookProgress: UIProgressView!
    @IBOutlet weak var UnionText: UILabel!
    @IBOutlet weak var UnionProgress: UIProgressView!
    @IBOutlet weak var CurryText: UILabel!
    @IBOutlet weak var CurryProgress: UIProgressView!
    @IBOutlet weak var BakerText: UILabel!
    @IBOutlet weak var BakerProgress: UIProgressView!
    @IBOutlet weak var WallowaText: UILabel!
    @IBOutlet weak var WallowaProgress: UIProgressView!
    @IBOutlet weak var CrookText: UILabel!
    @IBOutlet weak var CrookProgress: UIProgressView!
    @IBOutlet weak var GrantText: UILabel!
    @IBOutlet weak var GrantProgress: UIProgressView!
    @IBOutlet weak var HarneyText: UILabel!
    @IBOutlet weak var HarneyProgress: UIProgressView!

    override func viewDidLoad() {
//
//
//                       let url = URL(string: "https://raw.githubusercontent.com/AliFakhry/UpdatedData-/master/COUNTIES.txt")!
//                       let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
//                       guard let data = data else { return }
//                       let str = (String(data: data, encoding: .utf8)!)
//                       let fullNameArr = str.components(separatedBy: "-")
//
//                       let CasesTotal = fullNameArr[1]
//                       let DeathsTotal   = fullNameArr[2]
//                       let RatioTotal = fullNameArr[3]
//                       let RatioTotalD    = fullNameArr[4]
//
//                       let MultnomahCases = fullNameArr[6]
//                       let MultnomahDeaths     = fullNameArr[7]
//                       let MultnomahRatio = fullNameArr[8]
//                       let MultnomahRatioD    = fullNameArr[9]
//
//                       let MarionCases = fullNameArr[11]
//                       let MarionDeaths = fullNameArr[12]
//                       let MarionRatio = fullNameArr[13]
//                       let MarionRatioD = fullNameArr[14]
//
//                       let WashingtonCases = fullNameArr[16]
//                       let WashingtonDeaths = fullNameArr[17]
//                       let WashingtonRatio = fullNameArr[18]
//                       let WashingtonRatioD = fullNameArr[19]
//
//                       let ClackmasCases = fullNameArr[21]
//                       let ClackmasDeaths = fullNameArr[22]
//                       let ClackmasRatio = fullNameArr[23]
//                       let ClackmasRatioD = fullNameArr[24]
//
//                        let LinnCases = fullNameArr[26]
//                        let LinnDeaths = fullNameArr[27]
//                        let LinnRatio = fullNameArr[28]
//                        let LinnRatioD = fullNameArr[29]
//
//                        let DeschutesCases = fullNameArr[31]
//                        let DeschutesDeaths = fullNameArr[32]
//                        let DeschutesRatio = fullNameArr[33]
//                        let DeschutesRatioD = fullNameArr[34]
//
//                        let UmatillaCases = fullNameArr[36]
//                        let UmatillaDeaths = fullNameArr[37]
//                        let UmatillaRatio = fullNameArr[38]
//                        let UmatillaRatioD = fullNameArr[39]
//
//                        let PolkCases = fullNameArr[41]
//                        let PolkDeaths = fullNameArr[42]
//                        let PolkRatio = fullNameArr[43]
//                        let PolkRatioR = fullNameArr[44]
//
//                        let LaneCases = fullNameArr[46]
//                        let LaneDeaths = fullNameArr[47]
//                        let LaneRatio = fullNameArr[48]
//                        let LaneRatioR = fullNameArr[49]
//
//                        let YamhillCases = fullNameArr[51]
//                        let YamhillDeaths = fullNameArr[52]
//                        let YamhillRatio = fullNameArr[53]
//                        let YamhillRatioR = fullNameArr[54]
//
//                        let BentonCases = fullNameArr[56]
//                        let BentonDeaths = fullNameArr[57]
//                        let BentonRatio = fullNameArr[58]
//                        let BentonRatioR = fullNameArr[59]
//
//                        let JacksonCases = fullNameArr[61]
//                        let JacksonDeaths = fullNameArr[62]
//                        let JacksonRatio = fullNameArr[63]
//                        let JacksonRatioR = fullNameArr[64]
//
//                        let ClatsopCases = fullNameArr[66]
//                        let ClatsopDeaths = fullNameArr[67]
//                        let ClatsopRatio = fullNameArr[68]
//                        let ClatsopRatioR = fullNameArr[69]
//
//                        let CoosCases = fullNameArr[71]
//                        let CoosDeaths = fullNameArr[72]
//                        let CoosRatio = fullNameArr[73]
//                        let CoosRatioR = fullNameArr[74]
//
//                        let JosephineCases = fullNameArr[76]
//                        let JosephineDeaths = fullNameArr[77]
//                        let JosephineRatio = fullNameArr[78]
//                        let JosephineRatioR = fullNameArr[79]
//
//                        let DouglasCases = fullNameArr[81]
//                        let DouglasDeaths = fullNameArr[82]
//                        let DouglasRatio = fullNameArr[83]
//                        let DouglasRatioR = fullNameArr[84]
//
//                        let JeffersonCases = fullNameArr[86]
//                        let JeffersonDeaths = fullNameArr[87]
//                        let JeffersonRatio = fullNameArr[88]
//                        let JeffersonRatioR = fullNameArr[89]
//
//                        let MalheurCases = fullNameArr[91]
//                        let MalheurDeaths = fullNameArr[92]
//                        let MalheurRatio = fullNameArr[93]
//                        let MalheurRatioR = fullNameArr[94]
//
//                        let ColumbiaCases = fullNameArr[96]
//                        let ColumbiaDeaths = fullNameArr[97]
//                        let ColumbiaRatio = fullNameArr[98]
//                        let ColumbiaRatioR = fullNameArr[99]
//
//                        let WascoCases = fullNameArr[101]
//                        let WascoDeaths = fullNameArr[102]
//                        let WascoRatio = fullNameArr[103]
//                        let WascoRatioR = fullNameArr[104]
//
//                        let HoodRiverCases = fullNameArr[106]
//                        let HoodRiverDeaths = fullNameArr[107]
//                        let HoodRiverRatio = fullNameArr[108]
//                        let HoodRiverRatioR = fullNameArr[109]
//
//                        let MorrowCases = fullNameArr[111]
//                        let MorrowDeaths = fullNameArr[112]
//                        let MorrowRatio = fullNameArr[113]
//                        let MorrowRatioR = fullNameArr[114]
//
//                        let TilamookCases = fullNameArr[116]
//                        let TilamookDeaths = fullNameArr[117]
//                        let TilamookRatio = fullNameArr[118]
//                        let TilamookRatioR = fullNameArr[119]
//
//                        let UnionCases = fullNameArr[121]
//                        let UnionDeaths = fullNameArr[122]
//                        let UnionRatio = fullNameArr[123]
//                        let UnionRatioR = fullNameArr[124]
//
//                        let CurryText = fullNameArr[126]
//                        let CurryDeaths = fullNameArr[127]
//                        let CurryRatio = fullNameArr[128]
//                        let CurryRatioR = fullNameArr[129]
//
//                        let BakerText = fullNameArr[131]
//                        let BakerDeaths = fullNameArr[132]
//                        let BakerRatio = fullNameArr[133]
//                        let BakerRatioR = fullNameArr[134]
//
//                        let WallowaCases = fullNameArr[136]
//                        let WallowaDeaths = fullNameArr[137]
//                        let WallowaRatio = fullNameArr[138]
//                        let WallowaRatioR = fullNameArr[139]
//
//                        let CrookCases = fullNameArr[141]
//                        let CrookDeaths = fullNameArr[142]
//                        let CrookRatio = fullNameArr[143]
//                        let CrookRatioR = fullNameArr[144]
//
//                        let GrantCases = fullNameArr[146]
//                        let GrantDeaths = fullNameArr[147]
//                        let GrantRatio = fullNameArr[148]
//                        let GrantRatioR = fullNameArr[149]
//
//                        let HarneyCases = fullNameArr[151]
//                        let HarneyDeaths = fullNameArr[152]
//                        let HarneyRatio = fullNameArr[153]
//                        let HarneyRatioR = fullNameArr[154]
//
//                        let KlamathCases = fullNameArr[156]
//                        let KlamathDeaths = fullNameArr[157]
//                        let KlamathRatio = fullNameArr[158]
//                        let KlamathRatioR = fullNameArr[159]
//
//                        let LincolnCases = fullNameArr[161]
//                        let LincolnDeaths = fullNameArr[162]
//                        let LincolnRatio = fullNameArr[163]
//                        let LincolnRatioR = fullNameArr[164]
//
//                        let newDeaths = fullNameArr[165]
//
//                       DispatchQueue.main.async
//                       {
//                    self.TotalText.text = "Total: " + CasesTotal
//                        self.TotalProgress.setProgress(Float(1), animated: true)
//                      self.MultnomahText.text = "Multnomah: " + MultnomahCases
//                      self.MultnomahView.setProgress(Float(MultnomahRatio)!, animated: true)
//                        self.MarionText.text = "Marion: " + MarionCases
//                        self.MarionProgress.setProgress(Float(MarionRatio)!, animated: true)
//
//                        self.WashingtonText.text = "Washington: " + WashingtonCases
//                        self.WashingtonProgress.setProgress(Float(WashingtonRatio)!, animated: true)
//                        self.ClackmasText.text = "Clackmas: " + ClackmasCases
//                          self.ClackmasProgress.setProgress(Float(ClackmasRatio)!, animated: true)
//                        self.LinnText.text = "Linn: " + LinnCases
//                          self.LinnProgress.setProgress(Float(LinnRatio)!, animated: true)
//                        self.DeschutesText.text = "Deschutes: " + DeschutesCases
//                                                 self.DeschutesProgress.setProgress(Float(DeschutesRatio)!, animated: true)
//                        self.UmatillaText.text = "Umatilla: " + UmatillaCases
//                                                 self.UmatillaProgress.setProgress(Float(UmatillaRatio)!, animated: true)
//                        self.PolkText.text = "Polk: " + PolkCases
//                        self.PolkProgress.setProgress(Float(PolkRatio)!, animated: true)
//
//                        self.LaneText.text = "Lane: " + LaneCases
//                        self.LaneProgress.setProgress(Float(LaneRatio)!, animated: true)
//
//                        self.YamhillText.text = "Yamhill: " + YamhillCases
//                        self.YamhillProgress.setProgress(Float(YamhillRatio)!, animated: true)
//
//                        self.BentonText.text = "Benton: " + BentonCases
//                        self.BentonProgress.setProgress(Float(BentonRatio)!, animated:true)
//
//                        self.BentonText.text = "Benton: " + BentonCases
//                                               self.BentonProgress.setProgress(Float(BentonRatio)!, animated:true)
//                        self.JacksonText.text = "Jackson: " + JacksonCases
//                                                                     self.JacksonProgress.setProgress(Float(JacksonRatio)!, animated:true)
//
//                        self.ClatsopText.text = "Clatsop: " + ClatsopCases
//                                                                                    self.ClatsopProgress.setProgress(Float(ClatsopRatio)!, animated:true)
//
//                        self.CoosText.text = "Coos: " + CoosCases
//                                                                                                          self.CoosProgress.setProgress(Float(CoosRatio)!, animated:true)
//
//                        self.JosephineText.text = "Josephine: " + JosephineCases
//                        self.JosephineProgress.setProgress(Float(JosephineRatio)!, animated:true)
//
//                        self.DouglasText.text = "Douglas: " + DouglasCases
//                        self.DouglasProgress.setProgress(Float(DouglasRatio)!, animated:true)
//
//                        self.JeffersonText.text = "Jefferson: " + JeffersonCases
//                        self.JeffersonProgress.setProgress(Float(JeffersonRatio)!, animated:true)
//
//                        self.MalheurText.text = "Malheur: " + MalheurCases
//                        self.MalheurProgress.setProgress(Float(MalheurRatio)!, animated:true)
//
//                        self.ColumbiaText.text = "Columbia: " + ColumbiaCases
//                        self.ColumbiaProgress.setProgress(Float(ColumbiaRatio)!, animated:true)
//
//                        self.WascoText.text = "Wasco: " + WascoCases
//                        self.WascoProgress.setProgress(Float(WascoRatio)!, animated:true)
//
//                        self.HoodRiverText.text = "HoodRiver: " + HoodRiverCases
//                        self.HoodRiverProgress.setProgress(Float(HoodRiverRatio)!, animated:true)
//
//                        self.MorrowText.text = "Morrow: " + MorrowCases
//                        self.MorrowProgress.setProgress(Float(MorrowRatio)!, animated:true)
//
//                        self.TilamookText.text = "Tilamook: " + TilamookCases
//                        self.TilamookProgress.setProgress(Float(TilamookRatio)!, animated:true)
//
//                        self.UnionText.text = "Union: " + UnionCases
//                        self.UnionProgress.setProgress(Float(UnionRatio)!, animated:true)
//
//                        self.CurryText.text = "Curry: " + CurryText
//                        self.CurryProgress.setProgress(Float(CurryRatio)!, animated:true)
//
//                        self.BakerText.text = "Baker: " + BakerText
//                        self.BakerProgress.setProgress(Float(BakerRatio)!, animated:true)
//
//                        self.WallowaText.text = "Wallowa: " + WallowaCases
//                        self.WallowaProgress.setProgress(Float(WallowaRatio)!, animated:true)
//
//                        self.CrookText.text = "Crook: " + CrookCases
//                        self.CrookProgress.setProgress(Float(CrookRatio)!, animated:true)
//
//                        self.GrantText.text = "Grant: " + GrantCases
//                        self.GrantProgress.setProgress(Float(GrantRatio)!, animated:true)
//
//                        self.HarneyText.text = "Harney: " + HarneyCases
//                                               self.HarneyProgress.setProgress(Float(HarneyRatio)!, animated:true)
//
//                        self.Klamath.text = "Klamath: " + newDeaths
//                                               self.KlamathProgress.setProgress(Float(KlamathRatio)!, animated:true)
//
//                        self.LincolnText.text = "Lincoln: " + LincolnCases
//                        self.LincolnProgress.setProgress(Float(LincolnRatio)!, animated:true)
//
//                        self.tableView.reloadData()
//                       }
//    }
//    task.resume()
//    super.viewDidLoad()
        
    // Do any additional setup after loading the view.
    }

  @IBAction func SourcChecked(_ sender: Any) {
      let appURL = URL(string: "https://www.oregon.gov/OHA/PH/ABOUT/Documents/indicators/homeless-county.pdf")!
      let application = UIApplication.shared

      if application.canOpenURL(appURL) {
          application.open(appURL)
      } else {
          let webURL = URL(string: "https://www.oregon.gov/OHA/PH/ABOUT/Documents/indicators/homeless-county.pdf")!
          application.open(webURL)
      }
  }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let menuType = NewMenu(rawValue: indexPath.row) else { return }
        dismiss(animated: true) { [weak self] in
            print("Dismissing: \(menuType)")
            self?.didTapMenuType?(menuType)
        }
    }
}
